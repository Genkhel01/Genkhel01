﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace task3
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            int elem_num = 0;
            foreach (string file in System.IO.Directory.GetFiles(@"D:\donlowd\element", "*.txt", SearchOption.TopDirectoryOnly))
            {
                elem_num++;
            }
            string[] element_name = new string[elem_num];
            int num = 0;

            foreach (string file in System.IO.Directory.GetFiles(@"D:\donlowd\element", "*.txt", SearchOption.TopDirectoryOnly))
            {
                element_name[num] = Path.GetFileNameWithoutExtension(file);
                num++;
            }

            string constr =
                @"Data Source=LAPTOP-38K6OPT4\SQLEXPRESS;" +
                "Initial Catalog=lab04;" +
                "Integrated Security=True;";

            string[] crate = new string[elem_num];
            string[] atomic_number = new string[elem_num];
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            char[] sep = new char[] { ' ', '\t' };

            for (int i = 0; i < element_name.Length; i++)
            {
                crate[i] = "CREATE TABLE " + element_name[i] + "(wavelenght FLOAT, rel_intensy FLOAT); ";
                SqlCommand cmd = new SqlCommand(crate[i], con);
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Close();
                string[] row = File.ReadAllLines("D:/donlowd/element/" + element_name[i] + ".txt");


                string[] insert_el = new string[row.Length];

                for (int j = 0; j < row.Length; j++)
                {
                    string[] col = row[j].Split(sep, StringSplitOptions.RemoveEmptyEntries);
                    if (j == 0)
                    {

                        atomic_number[i] = col[0];
                    }
                    else
                    {
                        insert_el[j] = "INSERT INTO " + element_name[i] + "(wavelenght, rel_intensy) VALUES ";

                        insert_el[j] += "(" + col[0] + ", " + col[1] + ")";
                        insert_el[j] += ";";
                    }

                }
                string inser_an = "INSERT INTO " + "elements" + "(atomic_number, full_name) VALUES (" + atomic_number[i] + ", " + "'" + element_name[i] + "'" + ")";
                for (int j = 1; j < row.Length; j++)
                {
                    cmd = new SqlCommand(insert_el[j], con);
                    cmd.ExecuteNonQuery();
                }
                cmd = new SqlCommand(inser_an, con);
                cmd.ExecuteNonQuery();

                string inser = "INSERT INTO spectral_lines ";
                inser += "(atomic_number, wavelenght, rel_intensy) ";
                inser += "SELECT CAST('" + atomic_number[i] + "' AS INTEGER) AS atomic_number, ";
                inser += "(wavelenght * 0.1) AS wavelenght, rel_intensy ";
                inser += "FROM " + element_name[i] + ";";
                cmd = new SqlCommand(inser, con);
                cmd.ExecuteNonQuery();


            }

        }
    }
}
