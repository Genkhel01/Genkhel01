﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace task1
{
 

    internal class Triangle : Figure
    {
        public float side;
        public float half_side;
      

        PointF[] arrayPoints = new PointF[3];

        public void setSide()
        {
            side = setX;
            half_side = side * 0.5f;
        }

        static int lastNumber = 0;
        public int Nomer { get; }

        public override string setName()
        {

            nameFigure = nameFigure.ToString() + Nomer.ToString();
            return nameFigure;

        }

        public Triangle()
        {
            lastNumber++;
            Nomer = lastNumber;

        }

       
        

        public override bool test(float x, float y)
        {
            bool krak = false;
            float bruhTest1;
            float bruhTest2;
            float bruhTest3;
            bruhTest1 = (arrayPoints[0].X - x) * (arrayPoints[1].Y - arrayPoints[0].Y) - (arrayPoints[1].X - arrayPoints[0].X) * (arrayPoints[0].Y - y);
            bruhTest2 = (arrayPoints[1].X - x) * (arrayPoints[2].Y - arrayPoints[1].Y) - (arrayPoints[2].X - arrayPoints[1].X) * (arrayPoints[1].Y - y);
            bruhTest3 = (arrayPoints[2].X - x) * (arrayPoints[0].Y - arrayPoints[2].Y) - (arrayPoints[0].X - arrayPoints[2].X) * (arrayPoints[2].Y - y);
  
            if (((bruhTest1 >= 0 ) && (bruhTest2 >= 0) && (bruhTest3 >= 0)) || ((bruhTest1 <= 0) && (bruhTest2 <= 0) && (bruhTest3 <= 0)))
                krak = true;

            return krak;
        }

        public override void draw(Graphics g)
        {
            setSide();

            arrayPoints[0].X = pos_x - half_side;
            arrayPoints[0].Y = pos_y - half_side;

            arrayPoints[1].Y = pos_y + half_side;
            arrayPoints[1].X = pos_x - half_side;
            
            arrayPoints[2].Y = pos_y - half_side;
            arrayPoints[2].X = pos_x + half_side;
            
            Pen p = Pens.Black;
            if (selected == true) p = Pens.Red;
            g.DrawPolygon(p, arrayPoints);
        }
    }
}

