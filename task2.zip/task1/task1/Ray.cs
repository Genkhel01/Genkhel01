﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    public class Ray
    {

        Vec2 org; //Точка начала луча 
        Vec2 dir; //Единичный (нормальзованный) вектор направления луча 

        public Ray(Vec2 org, Vec2 dir)
        {
            dir.normalize(); //нормализация
            this.org = org;
            this.dir = dir;
        }

        private Vec2 pointAtDistance(float t) //t - расстояние от начала луча
        {
            Vec2 point = new Vec2(0.0F, 0.0F);
            point = org + dir * t;
            return point;
        }

    }
}
