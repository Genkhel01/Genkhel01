﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    public class RGB
    {
        public float r;
        public float g;
        public float b;

        //Конструктор по умлочанию (нужно ли определять r, g и b?)
        public RGB()
        {
        }

        public RGB(float x)
        {
            r = x; g = x; b = x;
        }

        public RGB(float r, float g, float b)
        {
            this.r = r; 
            this.g = g; 
            this.b = b;
        }

        public static RGB operator + (RGB a, RGB b)
        {
            float newR = a.r + b.r;
            float newG = a.g + b.g;
            float newB = a.b + b.b;
            RGB sumRGB = new RGB(newR, newG, newB);
            return sumRGB;
        }

        public static RGB operator -(RGB a, RGB b)
        {
            float newR = a.r - b.r;
            float newG = a.g - b.g;
            float newB = a.b - b.b;
            RGB sumRGB = new RGB(newR, newG, newB);
            return sumRGB;
        }

        public static RGB operator + (RGB a, float b)
        {
            a.r += b;
            a.g += b;
            a.b += b;
            return a;
        }
        public static RGB operator *(RGB a, float b)
        {
            RGB newObj = new RGB(a.r*b, a.g*b, a.b*b);
            return newObj;
        }

        public static RGB operator /(RGB a, float b)
        {
            RGB newObj = new RGB(a.r / b, a.g / b, a.b / b);
            return newObj;
        }

        public Color getColor()
        {
            Color retuningColor = new Color();
            retuningColor = Color.FromArgb(255, Math.Min(255, Math.Max(0, (int)r)), 
                        Math.Min(255, Math.Max(0, (int)g)),
                        Math.Min(255, Math.Max(0, (int)b)));
            return retuningColor;
        }

        public static RGB getRandom()
        {
            Random rand = new Random();
            RGB randomRGB = new RGB();
            randomRGB.r = rand.Next(0, 255);
            randomRGB.g = rand.Next(0, 255);
            randomRGB.b = rand.Next(0, 255);
            return randomRGB;
        }

    }
}
