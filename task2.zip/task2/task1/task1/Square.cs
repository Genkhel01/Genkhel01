﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace task2
{
    internal class Square : Figure
    {
        public float side;
        public float half_side;
        static int lastNumber = 0;
        public int Nomer { get; }

        public void setSide()
        {
            side = setX;
            half_side = side * 0.5f;
        }
       

        public Square()
        {
            
            lastNumber++;
            Nomer = lastNumber;
        }

        public override string setName()
        {

            nameFigure = nameFigure.ToString() + Nomer.ToString();
            return nameFigure;

        }

        public override float sdf(Vec2 p)
        {
            Vec2 d = (p - pos).abs() - half_side;
            float innerD = Math.Min(Math.Max(d.x, d.y), 0.0F); 
            float outerD = d.max(0.0F).len();

            return innerD + outerD;
        }



        public override bool test(float x, float y)
        {
            float xmin = pos.x - half_side;
            float xmax = pos.x + half_side;
            float ymin = pos.y - half_side;
            float ymax = pos.y + half_side;
            if (x < xmin || y < ymin) return false;
            if (x > xmax || y > ymax) return false;
            return true;
        }

        public override void draw(Graphics g)
        {
            setSide();
            
            float x0 = pos.x - half_side;
            float y0 = pos.y - half_side;
            Pen p = Pens.Black;
            if (selected == true) p = Pens.Red;
            g.DrawRectangle(p, x0, y0, side, side);
        }
    }
}
