﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    public class Vec2
    {
        public float x, y;

        public Vec2(float x, float y)
        {
            this.x = x;
            this.y = y;
        }

        //Конструктор по умлочанию (нужно ли определять x и y?)
        public Vec2()
        {
        }

        public static Vec2 operator + (Vec2 a, Vec2 b)
        {
            float newX = a.x + b.x;
            float newY = a.y + b.y;
            Vec2 sumVec2 = new Vec2(newX, newY);
            return sumVec2;
        }

        ////ввёл для удобства в Ray.pointAtDistance()
        //public static Vec2 operator + (Vec2 a, float b)
        //{
        //    float newX = a.x + b;
        //    float newY = a.y + b;
        //    Vec2 sumVec2 = new Vec2(newX, newY);
        //    return sumVec2;
        //}

        public static Vec2 operator - (Vec2 a, Vec2 b)
        {
            float newX = a.x - b.x;
            float newY = a.y - b.y;
            Vec2 sumVec2 = new Vec2(newX, newY);
            return sumVec2;
        }

        public static Vec2 operator - (Vec2 a, float b)
        {
            float newX = a.x - b;
            float newY = a.y - b;
            Vec2 sumVec2 = new Vec2(newX, newY);
            return sumVec2;
        }

        public static Vec2 operator * (Vec2 a, float b)
        {
            float newX = a.x * b;
            float newY = a.y * b;
            Vec2 sumVec2 = new Vec2(newX, newY);
            return sumVec2;
        }

        public static Vec2 fromPolar(float angle)
        {
            Vec2 newVec2 = new Vec2();
            newVec2.x = (float)Math.Cos((double)angle);
            newVec2.y = (float)Math.Sin((double)angle);
            return newVec2;
        }
        
        //возращает длинну вектора
        public float len()
        {
            //Должно работать
            return (float)Math.Sqrt(this.x*this.x+this.y*this.y);
        }

        public Vec2 abs()
        {
            Vec2 returningVec2 = new Vec2();
            returningVec2.x = Math.Abs(this.x);
            returningVec2.y = Math.Abs(this.y);
            return returningVec2;
        }

        //возвращающая новый экземпляр класса,
        //где для каждого компонента выбирается макисмальное из двух чисел
        //Функция max() при запонениии компонента
        //класса выбирает значение исходного компонента или значение переданное
        //в функцию (берется максимальное из двух)
        public Vec2 max(float v)
        {
            Vec2 returningVec2 = new Vec2();
            returningVec2.x = Math.Max(x, v);
            returningVec2.y = Math.Max(y, v);
            return returningVec2;
        }

        public void normalize()
        {
            this.x = this.x / this.len();
            this.y = this.y / this.len();
        }

    }
}
